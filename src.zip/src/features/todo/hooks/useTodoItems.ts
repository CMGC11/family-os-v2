import { useEffect, useState } from 'react';
import {
  deleteTodoItem,
  fetchTodoItems,
  insertTodoItem,
  updateTodoItemDone,
} from '../services/todoSupabaseService';
import { requireSupabaseClient } from '../../../lib/supabase/client';
import { getCurrentHouseholdId } from '../../../lib/supabase/household';
import type { TaskItem } from '../types';

export function useTodoItems() {
  const [items, setItems] = useState<TaskItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    let cancelled = false;

    async function loadItems() {
      try {
        setIsLoading(true);
        setErrorMessage('');

        const nextItems = await fetchTodoItems();

        if (!cancelled) {
          setItems(nextItems);
        }
      } catch (error) {
        console.error('Failed to load todo items:', error);

        if (!cancelled) {
          setErrorMessage(error instanceof Error ? error.message : 'Failed to load todo items.');
        }
      } finally {
        if (!cancelled) {
          setIsLoading(false);
        }
      }
    }

    loadItems();

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    let cancelled = false;
    const supabase = requireSupabaseClient();
    let channel: ReturnType<typeof supabase.channel> | null = null;

    async function subscribe() {
      try {
        const householdId = await getCurrentHouseholdId();

        if (cancelled) return;

        channel = supabase
          .channel(`todo-items-realtime-${householdId}`)
          .on(
            'postgres_changes',
            {
              event: '*',
              schema: 'public',
              table: 'todo_items',
              filter: `household_id=eq.${householdId}`,
            },
            async () => {
              try {
                const nextItems = await fetchTodoItems();
                setItems(nextItems);
              } catch (error) {
                console.error('Failed to refresh todo items after realtime event:', error);
                setErrorMessage(error instanceof Error ? error.message : 'Failed to sync todo items.');
              }
            },
          )
          .subscribe();
      } catch (error) {
        console.error('Failed to subscribe to todo realtime:', error);
        setErrorMessage(error instanceof Error ? error.message : 'Failed to subscribe to todo sync.');
      }
    }

    subscribe();

    return () => {
      cancelled = true;

      if (channel) {
        supabase.removeChannel(channel);
      }
    };
  }, []);

  async function addItem(title: string, area = 'Family', due = 'Today') {
    const cleanTitle = title.trim();

    if (!cleanTitle) return;

    try {
      setErrorMessage('');

      const row = await insertTodoItem(cleanTitle, area, due);

      const newItem: TaskItem = {
        id: row.id,
        household_id: row.household_id,
        title: row.title,
        area: row.area || 'Family',
        due: row.due || 'Today',
        done: Boolean(row.is_done),
        created_at: row.created_at ?? new Date().toISOString(),
      };

      setItems((current) => [newItem, ...current]);
    } catch (error) {
      console.error('Failed to insert todo item:', error);
      setErrorMessage(error instanceof Error ? error.message : 'Failed to add task.');
    }
  }

  async function toggleItem(id: string) {
    const target = items.find((item) => item.id === id);

    if (!target) return;

    const nextDone = !target.done;

    setItems((current) =>
      current.map((item) =>
        item.id === id ? { ...item, done: nextDone } : item,
      ),
    );

    try {
      setErrorMessage('');
      await updateTodoItemDone(id, nextDone);
    } catch (error) {
      console.error('Failed to update todo item:', error);

      setItems((current) =>
        current.map((item) =>
          item.id === id ? { ...item, done: target.done } : item,
        ),
      );

      setErrorMessage(error instanceof Error ? error.message : 'Failed to update task.');
    }
  }

  async function deleteItem(id: string) {
    const previousItems = items;

    setItems((current) => current.filter((item) => item.id !== id));

    try {
      setErrorMessage('');
      await deleteTodoItem(id);
    } catch (error) {
      console.error('Failed to delete todo item:', error);

      setItems(previousItems);
      setErrorMessage(error instanceof Error ? error.message : 'Failed to delete task.');
    }
  }

  return {
    items,
    isLoading,
    errorMessage,
    addItem,
    toggleItem,
    deleteItem,
  };
}